// ShellError.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include <string>

int main(int argc, char** argv)
{
    std::cout << "ShellError Test Program" << std::endl;
    if (argc == 1) {
        return 0;
    }
    else if (argc == 2) {
        std::cout << "Exit: " << argv[1];
        return std::stoi(argv[1]);
    }
    else if (argc > 2) {
        std::cout << "Exit: " << argv[1] << " Delayed: " << argv[2] << " milliseconds\n";
        Sleep(std::stoi(argv[2]));
        return std::stoi(argv[1]);
    }
}