#include "BatcherApp.hpp"
#include <stdexcept>
#include <iostream>
#include <vector>
using namespace std;

BatcherApp* BatcherApp::thisApp_sm = nullptr;

BatcherApp::BatcherApp() {
	if (thisApp_sm) {
		cerr << "Error: more than one instance of BatcherApp\n";
		std::exit(EXIT_FAILURE);
	}
	thisApp_sm = this;
}

int main(int argc, char* argv[]) try {
#if defined(_DEBUG) && defined(_WIN32)
	int dbgFlags = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
	dbgFlags |= _CRTDBG_CHECK_ALWAYS_DF;
	dbgFlags |= _CRTDBG_DELAY_FREE_MEM_DF;
	dbgFlags |= _CRTDBG_LEAK_CHECK_DF;
	_CrtSetDbgFlag(dbgFlags);

	_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_DEBUG | _CRTDBG_MODE_FILE);
	_CrtSetReportFile(_CRT_WARN, _CRTDBG_FILE_STDOUT);
#endif

	set_terminate([]() {
		cout << "Error (main): Unhandled exception\n";
		exit(EXIT_FAILURE);
		});

	BatcherApp::thisApp_sm->args_m.assign(argv, argv + argc);

	auto exitCode = BatcherApp::thisApp_sm->execute();
	return exitCode;
}
catch (char const* msg) {
	cerr << "Error (main) caught exception string: " << msg << endl;
}
catch (runtime_error& e) {
	cerr << "Error (main) caught runtime_error: " << e.what() << endl;
	return EXIT_FAILURE;
}
catch (logic_error& e) {
	cerr << "Error (main) caught logic_error: " << e.what() << endl;
	return EXIT_FAILURE;
}
catch (exception& e) {
	cerr << "Error (main) caught exception: " << e.what() << endl;
}