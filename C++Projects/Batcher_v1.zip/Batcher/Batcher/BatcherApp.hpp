#pragma once
#if defined(_WIN32)
#include <crtdbg.h>
#include <Windows.h>
#include <deque>
#include <string>
#endif

class BatcherApp {
	friend int main(int argc, char* argv[]);
	static BatcherApp* thisApp_sm;

	using CommandLineArgs = std::deque<std::string>;
	CommandLineArgs args_m;

protected:
	BatcherApp();
	virtual int execute() = 0;
	CommandLineArgs const& get_args() const { return args_m; }
};

#define MAKEAPP(name)\
	class name : public BatcherApp {\
		int execute() override;\
} name##_g;\
int name ::execute()