#include <iostream>
#include "BatcherApp.hpp"
#include <string>
#include <fstream>
#include <vector>
#include <process.h>
#include <iomanip>
using namespace std;

//Program struct to make storing program data easier
struct Program {
	int launchGroup = 0;
	string name = "";
	string cmdArgs = "";
	SYSTEMTIME kTime, uTime;
	DWORD exitCode = 0;
	STARTUPINFO sInfo{ 0 };
	PROCESS_INFORMATION pInfo{ 0 };
};

//Helper Mehthods
/*
*	ltrim, rtrim, trim------------------------------------------------------------
	Gets rid of random spaces at the beginning and ends of strings
*/
string ltrim(const string& s) {
	size_t start = s.find_first_not_of(' ');
	return (start == string::npos) ? "" : s.substr(start);
}

string rtrim(const string& s) {
	size_t end = s.find_last_not_of(' ');
	return (end == string::npos) ? "" : s.substr(0, end + 1);
}

string trim(const string& s) {
	return rtrim(ltrim(s));
}
//	ltrim, rtrim, trim------------------------------------------------------------

/*
* sortProgs-----------------------------------------------------------------------
* sorts the programs, based on their launch groups, in ascending order
*/
vector<Program> sortProgs(vector<Program> programs) {
	vector<Program> sortedProgs;
	if (!programs.empty()) {
		int min = programs.front().launchGroup; //use the first element's group number to avoid problems with assuming what the range is
		int max = programs.front().launchGroup;
		int sortedGroup; //keep track of the last group that was sorted
		bool sorted = false;

		//find the lowest and highest group number
		for (Program p : programs) {
			if (p.launchGroup < min)
				min = p.launchGroup;
			if (p.launchGroup > max)
				max = p.launchGroup;
		}

		//from lowest to highest, push programs to sorted vector until all programs are sorted
		while (!sorted) {
			for (Program p : programs) {
				if (p.launchGroup == min) {
					sortedProgs.push_back(p);
					if (min == max)
						sorted = true;
				}
			}
			sortedGroup = min;
			min = max;
			for (Program p : programs) {
				if (p.launchGroup < min && p.launchGroup > sortedGroup)
					min = p.launchGroup;
			}
		}
	}
	return sortedProgs;
}
// sortProgs-----------------------------------------------------------------------

/*
* readFile-------------------------------------------------------------------------
* Reads a file of programs and command arguments and collects them in a vector to be
* sorted
*/
vector<Program> readFile(string fileName) {
	vector<Program> progs;
	ifstream file(fileName);
	if (file.is_open()) {
		string line;
		size_t pos = 0;
		Program p;
		string str[3];
		int idx = 0;
		while (getline(file, line)) {
			if (line == "")//skip blank lines
				continue;

			//split each line into strings representing data: launch group, program name, and args
			while ((pos = line.find(',')) != string::npos) {
				str[idx++] = line.substr(0, pos);
				line.erase(0, pos + 1);
			}
			str[idx] = line;
			//create Program to hold data and make organizing easier
			p.launchGroup = stoi(str[0]);
			p.name = trim(str[1]);
			p.cmdArgs = str[2];
			//collect Programs
			progs.push_back(p);
			idx = 0;
		}
		file.close();
		return sortProgs(progs);
	}
	else {
		cout << "Could not open file " << fileName << endl;
		return sortProgs(progs);
	}
}
// readFile-------------------------------------------------------------------------

/*
* printReport-----------------------------------------------------------------------
* prints out the program results in tabular format
*/
void printReport(vector<Program> programs) {
	int groupToPrint = programs.front().launchGroup - 1;
	cout << "Launch Times\n";
	for (size_t i = 0; i < programs.size(); i++) {
		if (groupToPrint < programs[i].launchGroup) {
			groupToPrint = programs[i].launchGroup;
			cout << "\nGroup:" << groupToPrint << endl;
		}
		cout << "Kernel Time: " << programs[i].kTime.wMinute << ":" << programs[i].kTime.wSecond << "." << setw(3) << setfill('0') << programs[i].kTime.wMilliseconds << " ";
		cout << "User Time: " << programs[i].uTime.wMinute << ":" << programs[i].uTime.wSecond << "." << setw(3) << setfill('0') << programs[i].uTime.wMilliseconds << " ";
		cout << "Exit Code: " << programs[i].exitCode << " ";
		cout << "Arguments: " << programs[i].launchGroup << " " << programs[i].name << " " << programs[i].cmdArgs << endl;


	}

	cout << "\nErrors:\n";
	for (Program p : programs) {
		if (p.exitCode != 0) {
			cout << "G#: " << p.launchGroup << " " << "Command: " << p.name << " " << "Params: " << p.cmdArgs << endl;
			cout << "-----> Error = " << p.exitCode << endl;
		}
	}
}
// printReport-----------------------------------------------------------------------

MAKEAPP(Batcher) {
	//if an argument was passed
	if (get_args().size() > 1) {
		string file = get_args().at(1);
		vector<Program> progs = readFile(file); //read file and get programs
		if (!progs.empty()) { //if file could be read and programs populated

			wstring app = L"";
			wstring params = L"";
			wstring command = L"";

			int currGroup = 0; // keep track of which group is launching
			for (size_t i = 0; i < progs.size(); i++) {
				currGroup = progs[i].launchGroup;
					app = L"";
					params = L"";
					command = L"";
					if (progs[i].name == "ShellError")//If program name is ShellError, point to ShellError in this solution
						app = L"\"..\\Debug\\ShellError.exe\"";
					else { //if not, assume it's a program on user device
						app = L"\"c:/windows/";
						app.append(progs[i].name.begin(), progs[i].name.end());
						app.append(L"\"");
					}
					params.append(progs[i].cmdArgs.begin(), progs[i].cmdArgs.end());
					command = app + L" " + params;
					progs[i].sInfo.cb = sizeof(STARTUPINFO);
					unsigned long const CP_MAX_COMMAND = 32768;
					try {
						wchar_t* commandline = new wchar_t[CP_MAX_COMMAND];
						wcsncpy_s(commandline, CP_MAX_COMMAND, command.c_str(), command.size() + 1);
						auto res = CreateProcess(
							NULL,
							commandline,
							NULL,
							NULL,
							false,
							CREATE_NEW_CONSOLE,
							NULL,
							NULL,
							&progs[i].sInfo,
							&progs[i].pInfo
						);

						if (res == 0) {
							cerr << "Error: " << GetLastError() << endl;
						}
						delete[]commandline;
					}
					catch (bad_alloc&) {
						wcerr << L"Insufficient memory to launch application\n";
						return 0;
					}
					if (i < progs.size() - 1) {
						if (progs[i + 1].launchGroup > currGroup) {
							WaitForSingleObject(progs[i].pInfo.hProcess, INFINITE);//wait for previous group to finish before moving one
						}
					}
					else
						WaitForSingleObject(progs[i].pInfo.hProcess, INFINITE);//wait for last program and its group

					GetExitCodeProcess(progs[i].pInfo.hProcess, &progs[i].exitCode); //get exit code
				//}

				//get kernel/user times
				FILETIME createTime, exitTime, kernelTime, userTime;
				GetProcessTimes(progs[i].pInfo.hProcess, &createTime, &exitTime, &kernelTime, &userTime);
				FileTimeToSystemTime(&kernelTime, &progs[i].kTime);
				FileTimeToSystemTime(&userTime, &progs[i].uTime);

				//close handles
				CloseHandle(progs[i].pInfo.hThread);
				CloseHandle(progs[i].pInfo.hProcess);

			}

			printReport(progs);
			return EXIT_SUCCESS;
		}
		else {
			cout << "File could not be read";
			return EXIT_FAILURE;
		}
	}
	else {
		cout << "no args\n";
	}

	return 0;
}