#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iostream>
#include <string>
using namespace std;

#pragma comment (lib, "ws2_32.lib")

unsigned short constexpr PORT = 49153;

int main(int argc, char* argv[])
{
    PCSTR ip = "";

    if (argc > 2) {
        cerr << "Too many arguments";
        return EXIT_FAILURE;
    }

    if (argc == 2)
        ip = argv[1];
    else
        ip = "127.0.0.1";

    std::cout << "Remote Ultragrep Client\n";

    //initialize WSA
    WSAData wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        cerr << "WSAStartup failed: " << iResult << endl;
        return EXIT_FAILURE;
    }

    //create TCP socket
    SOCKET hSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    //create server address
    sockaddr_in serverAddress = { 0 };
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    inet_pton(AF_INET, ip, &(serverAddress.sin_addr));

    //connect to socket
    if (connect(hSocket, (SOCKADDR*)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cerr << "connect() failed\n";
        goto done;
    }

    {
        int constexpr MAXLINE = 255;
        char recvline[MAXLINE + 1];

        //instructions
        cout << "Enter [filename/filepath] [regex] [file extension]* to run UltraGrep on server\n";
        cout << "*optional\n\n";
        cout << "Enter '!quit' to disconnect\n";
        cout << "_________________________________\n\n";

        //test folder: ../UltraGrep/testfolder 
        //test regex: text

        //take user input
        string line;
        while (getline(cin, line)) {
            //send user input to server
            send(hSocket, line.c_str(), (int)line.size(), 0);
            int n = recv(hSocket, recvline, MAXLINE, 0);

            //get server response
            if (n == -1)
                cout << "no reply\n";
            else {
                recvline[min(n, MAXLINE)] = 0;
                string msg = recvline;
                if (msg == "server exit"s) {
                    cout << "Server terminated\n";
                    break;
                }
                cout << recvline << endl;
            }
        }
    }

    //terminate
done:
    closesocket(hSocket);
    WSACleanup();
}