#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

#pragma comment (lib, "ws2_32.lib")

unsigned short constexpr PORT = 49153;

int main(int argc, char* argv[])
{
    PCSTR ip = "";

    if (argc > 2) {
        cerr << "Too many arguments";
        return EXIT_FAILURE;
    }

    //Set ip
    if (argc == 2)
        ip = argv[1];
    else
        ip = "127.0.0.1";

    cout << "Remote Ultragrep Server\n";

    //initialize WSA
    WSAData wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        cerr << "WSAStartup failed: " << iResult << endl;
        return EXIT_FAILURE;
    }

    //create TCP socket
    SOCKET hSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    //create server address
    sockaddr_in serverAddress = { 0 };
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    inet_pton(AF_INET, ip, &(serverAddress.sin_addr));

    //bind to socket
    if (bind(hSocket, (SOCKADDR*)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cerr << "Bind() failed\n";
        cout << "Closing listening socket.\n";
        goto done;
    }

    cout << "TCP Socket bound\n";

    //start server listen
    if (listen(hSocket, 1) == SOCKET_ERROR) {
        cerr << "Error listening on socket\n";
        goto done;
    }

    {
        //wait for client
        cout << "Waiting for connection\n";
        SOCKET hAccepted = SOCKET_ERROR;
        while (hAccepted == SOCKET_ERROR) {
            hAccepted = accept(hSocket, NULL, NULL);
        }

        //client connected successfully
        cout << "Client connected\n";

        //test folder: ../UltraGrep/testfolder 
        //test regex: text

        //take client input
        for (;;) {
            sockaddr clientAddress;
            socklen_t cbClientAddress = sizeof(clientAddress);
            int constexpr MAXLINE = 255;
            char msg[MAXLINE + 1];

            //show received input
            int n = recv(hAccepted, msg, MAXLINE, 0);
            msg[min(n, MAXLINE)] = 0;
            cout << "Recv: " << msg << endl;

            //if user wants to quit
            if (!strcmp(msg, "!quit")) {
                auto terminateMsg = "server exit"s;
                send(hAccepted, terminateMsg.c_str(), (int)terminateMsg.size(), 0);
                break;
            }


            //open pipe to capture UltraGrep output
            ostringstream oss;
            string params = msg;
            string commandline = "UltraGrep.exe " + params;
            FILE* pPipe = _popen(commandline.c_str(), "rt");
            if (pPipe == NULL) {
                cerr << "Could not open pipe to command shell\n";
                goto done;
            }

            int ch;
            while ((ch = fgetc(pPipe)) != EOF)
                oss.put(ch);

            _pclose;

            //send captured output to client
            string s = oss.str();
            cout << "Captured " << s.size() << " bytes from UltraGrep\n\n";
            send(hAccepted, s.c_str(), (int)s.size(), 0);
        }
    }

    //terminate
done:
    cout << "Closing listening socket\n";
    closesocket(hSocket);
    WSACleanup();
}
