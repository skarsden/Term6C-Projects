#include <iostream>
#include <string>
#include <filesystem>
#include <fstream>
#include <regex>
#include <vector>
#include <Windows.h>
#include <thread>
#include <mutex>
using namespace std;

mutex consoleMtx;
mutex taskMtx;

//struct to aid with printing report
struct ReportInfo {
	string fileName = "";
	vector<string> matchedLines;
	vector<unsigned> lineNums;
};

vector<string> ext;   //file extension
bool verbose = false; //verbose mode
unsigned fileMatches = 0; //number of files with matches
unsigned totalMatches = 0; //total number of lines with matches
vector<ReportInfo> info; //Info to be reported

//SearchFile: searches through a file's text to find any matches to regex 
void searchFile(filesystem::path filename, string expression) {
	ReportInfo ri;
	ifstream f(filename);
	string line = "";
	unsigned lineCount = 0; //keep track of wich line matches were found on
	bool matchFound = false;
	if (f.is_open()) {
		if (verbose) {
			{lock_guard<mutex> lk(consoleMtx);
			cout << "Grepping: " << filename.string() << endl; } //printing verbose data
		}
		while (getline(f, line)) {
			{lock_guard<mutex> lk(taskMtx);
			lineCount++;
			if (regex_search(line, regex(expression))) {
				if (verbose)
					cout << "Matched: " << filename.string() << " [" << lineCount << "] " << line << endl;
				totalMatches++; //add to total matches if one is found
				matchFound = true;
				ri.matchedLines.push_back(line);
				ri.lineNums.push_back(lineCount);
			}
			}
		}
	}
	if (matchFound) {
		{lock_guard<mutex> lk(taskMtx);
		fileMatches++;
		ri.fileName = filename.string();
		info.push_back(ri);
		}
	}
}

//searchDir: searches the contents of a directory
void searchDir(filesystem::path dir, string expression) {
	if (verbose) {
		{lock_guard<mutex> lk(consoleMtx);
		cout << "Scanning: " << dir.string() << endl; }
	}
	for (const auto& entry : filesystem::directory_iterator(dir)) {
		if (entry.is_directory())
			jthread(searchDir, entry.path(), expression).join(); //if another directory is found, call function again for it
		else
			for (string fileExt : ext) //if a file is found, check if the extension is one we're looking for
				if (entry.path().string().find(fileExt) != string::npos)
					jthread(searchFile, entry.path(), expression).join(); //if the extension is on our list check the file
	}
}

//report(): prints out the result of the grepping
void report() {
	if (verbose)
		cout << endl; //only need to add this space if verbose text is printed above, makes it prettier/easier to read
	cout << "Grep Report: \n";
	for (ReportInfo r : info) {
		cout << r.fileName << endl;
		for (unsigned i = 0; i < r.matchedLines.size(); i++) {
			cout << "\t[" << r.lineNums[i] << "] " << r.matchedLines[i] << endl;
		}
	}
	cout << "\nFiles with matched: " << fileMatches;
	cout << "\nTotal number of matches: " << totalMatches << endl;
}

int main(int argc, char* argv[])
{
	if (argc < 3 || argc > 5) {
		cout << "Error: Incorrect number of Command Line Arguments\n";
		return EXIT_FAILURE;
	}

	string path = "";     //directory path
	string exp = "";      //regular expression

	if (argc == 5) {
		verbose = true;
		path = argv[2];
		exp = argv[3];
		string extensions = argv[4];
		size_t pos = 0;
		while ((pos = extensions.find('.')) != string::npos) { //leaves the first element of ext empty since extensions string starts with '.'
			ext.push_back(extensions.substr(0, pos));
			extensions.erase(0, pos + 1);
		}
		ext[0] = "." + extensions; //replacing the empty first element with the remaining extension (and add the '.' back to it)
	}
	else if (argc == 4) {
		string arg1 = argv[1];
		if (arg1 == "-v") {
			verbose = true;
			path = argv[2];
			exp = argv[3];
			ext.push_back(".txt");
		}
		else {
			path = argv[1];
			exp = argv[2];
			string extensions = argv[3];
			size_t pos = 0;
			while ((pos = extensions.find('.')) != string::npos) {
				ext.push_back(extensions.substr(0, pos));
				extensions.erase(0, pos + 1);
			}
			ext[0] = "." + extensions;
		}
	}
	else {
		verbose = false;
		path = argv[1];
		exp = argv[2];
		ext.push_back(".txt");
	}

	jthread(searchDir,path, exp).join();
	report();
}
